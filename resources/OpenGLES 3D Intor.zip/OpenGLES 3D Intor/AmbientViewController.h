//
//  AmbientViewController.h
//  OpenGLES 3D Intor
//
//  Created by Elhassan Ahmed on 5/3/15.
//  Copyright (c) 2015 Elhassan Ahmed. All rights reserved.
//

#import "ParentGLKViewController.h"

@interface AmbientViewController : ParentGLKViewController

@end
