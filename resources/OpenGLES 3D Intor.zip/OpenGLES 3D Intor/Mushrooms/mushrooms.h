//#import <GLKit/GLKit.h>
//
//#import "Vertex.h"
//
//const GLKVector4 Mushroom_Cylinder_mushroom_ambient;
//const GLKVector4 Mushroom_Cylinder_mushroom_diffuse;
//const GLKVector4 Mushroom_Cylinder_mushroom_specular;
//const float Mushroom_Cylinder_mushroom_shininess;
//const VertexTextureNorm Mushroom_Cylinder_mushroom_Vertices[420];
//
