//
//  ModelViewController.h
//  OpenGLES 3D Intor
//
//  Created by Elhassan Ahmed on 5/6/15.
//  Copyright (c) 2015 Elhassan Ahmed. All rights reserved.
//

#import "ParentGLKViewController.h"

@interface ModelViewController : ParentGLKViewController

@end
