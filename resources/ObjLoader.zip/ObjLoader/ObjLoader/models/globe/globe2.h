#import <GLKit/GLKit.h>

#import "Vertex.h"

const GLKVector4 Sphere_globe_ambient;
const GLKVector4 Sphere_globe_diffuse;
const GLKVector4 Sphere_globe_specular;
const float Sphere_globe_shininess;
const Vertex Sphere_globe_Vertices[6696];

