﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CoyoteRoadrunner
{
    class Program
    {
        static void Main( string[] args )
        {
            const int SIM_STEP_COUNT = 10;

            // set up the starting conditions
            var pRR = new CVector( -60, 0 );
            var vRR = new CVector( -1, -1 );
            var pC = new CVector( 20, 20 );
            var sC = 2;

            // calculate the intercept point
            CVector pIntercept;
            double timeIntercept;
            var vC_Intercept = pC.Intercept( sC, pRR, vRR, out pIntercept, out timeIntercept );
            if (vC_Intercept == null)
            {
                Console.WriteLine( "Will not intercept" );
                return;
            }

            // Check the result
            var check = pC + vC_Intercept * timeIntercept;
            if (!pIntercept.AreSame( check ))
            {
                Console.WriteLine( "ERROR! Not the same: iPos={0}   Calculated={1}", pIntercept, check );
                return;
            }
            if (!vC_Intercept.Length.IsClose( sC ))
            {
                Console.WriteLine( "The Intercept Velocity vector does not match the Coyote's Speed!" );
                return;
            }

            // Output results
            Console.WriteLine( "Coyote starts at {0}, Roadrunner starts at {1}", pC, pRR );
            Console.WriteLine( "Coyote Speed: {0:N3}   Roadrunner Speed: {1:N3}", vC_Intercept.Length, vRR.Length );
            Console.WriteLine( "Intercept at {0} in {1:N3} seconds: Intercept Velocity = {2}", pIntercept, timeIntercept, vC_Intercept );
            Console.WriteLine();

            // Simulate Movement
            CVector rr = new CVector( pRR );
            CVector c = new CVector( pC );
            double t = 0;
            double dt = timeIntercept / SIM_STEP_COUNT;

            Console.WriteLine( "{0,-10} {1,-20} {2,-20}", "Time", "Coyote", "RoadRunner" );
            for (int i = 0; i < SIM_STEP_COUNT; i++)
            {
                Console.WriteLine( "{0,-10:N4} {1,-20} {2,-20}", t, c, rr );
                c += vC_Intercept * dt;
                rr += vRR * dt;
                t += dt;
            }
            Console.WriteLine( "{0,-10:N4} {1,-20} {2,-20}", t, c, rr );
            Console.WriteLine();
            Console.WriteLine( "Coyote is {0:N10} units away from Roadrunner.", c.Distance( rr ) );
        }
    }

    public static class MathExt
    {
        /// <summary>
        /// Return TRUE if two floating point numbers are very close to each other, defined by some tolerance. This is 
        /// meant to deal with "Floating Point Errors" when multiple floating point numbers are derived using different 
        /// equations that should yield equal results.
        /// </summary>
        /// <param name="p_this">The number to compare against some other number</param>
        /// <param name="p_other">The other number</param>
        /// <returns>TRUE if the numbers are "close", FALSE if they are outside the tolerance</returns>
        public static bool IsClose( this double p_this, double p_other )
        {
            const double tolerance = 0.000000001;

            double delta = p_this - p_other;
            if (delta < 0)
                delta = -delta;
            return delta < tolerance;
        }
    }

    public static class CMath
    {
        /// <summary>
        /// Solve a quadratic equation in the form ax^2 + bx + c = 0
        /// </summary>
        /// <param name="a">Coefficient for x^2</param>
        /// <param name="b">Coefficient for x</param>
        /// <param name="c">Constant</param>
        /// <param name="solution1">The first solution</param>
        /// <param name="solution2">The second solution</param>
        /// <returns>TRUE if a solution exists, FALSE if one does not</returns>
        public static bool QuadraticSolver( double a, double b, double c, out double solution1, out double solution2 )
        {
            if (a == 0)
            {
                if (b == 0)
                {
                    solution1 = solution2 = double.NaN;
                    return false;
                }
                else
                {
                    solution1 = solution2 = -c / b;
                    return true;
                }
            }

            double tmp = b * b - 4 * a * c;
            if (tmp < 0)
            {
                solution1 = solution2 = double.NaN;
                return false;
            }

            tmp = Math.Sqrt( tmp );
            double _2a = 2 * a;
            solution1 = (-b + tmp) / _2a;
            solution2 = (-b - tmp) / _2a;
            return true;
        }
    }
}
