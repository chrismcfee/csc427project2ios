﻿using System;


namespace CoyoteRoadrunner
{
    /// <summary>
    /// Basic 2-d vector functionality
    /// </summary>
    public class CVector
    {
        /// <summary>
        /// The 'X' coordinate
        /// </summary>
        public double X;

        /// <summary>
        /// The 'Y' coordinate
        /// </summary>
        public double Y;


        /// <summary>
        /// Construct a (0,0) vector
        /// </summary>
        public CVector()
        {
        }

        /// <summary>
        /// Construct a vector with set X,Y
        /// </summary>
        /// <param name="x">The 'X' coordinate</param>
        /// <param name="y">The 'Y' coordinate</param>
        public CVector( double x, double y )
        {
            X = x;
            Y = y;
        }

        /// <summary>
        /// Copy constructor from another 2d vector
        /// </summary>
        /// <param name="p_other">The 2d vector to copy</param>
        public CVector( CVector p_other )
        {
            X = p_other.X;
            Y = p_other.Y;
        }


        /// <summary>
        /// Is another vector the "same" as this vector?
        /// </summary>
        /// <param name="p_other">The vector to compare to this one</param>
        /// <returns>TRUE if the X,Y values are "close"</returns>
        public bool AreSame( CVector p_other )
        {
            return X.IsClose( p_other.X ) && Y.IsClose( p_other.Y );
        }


        /// <summary>
        /// The Square of the Length of this vector- Also the dot-product of this vector and itself
        /// </summary>
        public double LengthSquared
        {
            get { return X * X + Y * Y; }
        }

        /// <summary>
        /// The Length of this vector (same as "magnitude")
        /// </summary>
        public double Length
        {
            get { return Math.Sqrt( X * X + Y * Y ); }
        }

        /// <summary>
        /// The Magnitude of this vector (same as "length")
        /// </summary>
        public double Magnitude
        {
            get { return Math.Sqrt( X * X + Y * Y ); }
        }


        /// <summary>
        /// The square of the distance between this vector and another vector (assumed to be point vectors)
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>The distance squared between this and another vector</returns>
        public double DistanceSquared( CVector p_other )
        {
            double xx = X - p_other.X;
            double yy = Y - p_other.Y;
            return xx * xx + yy * yy;
        }

        /// <summary>
        /// The distance between this vector and another vector (assumed to be point vectors)
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>The distance between this and another vector</returns>
        public double Distance( CVector p_other )
        {
            return Math.Sqrt( DistanceSquared( p_other ) );
        }


        /// <summary>
        /// Add two vectors together and get a new CVector
        /// </summary>
        /// <param name="p_1">The left operand</param>
        /// <param name="p_2">The right operand</param>
        /// <returns>A new CVector resulting from the sum of two vectors</returns>
        public static CVector operator +( CVector p_1, CVector p_2 )
        {
            return new CVector( p_1.X + p_2.X, p_1.Y + p_2.Y );
        }

        /// <summary>
        /// Subtract two vectors together and get a new CVector
        /// </summary>
        /// <param name="p_1">The left operand</param>
        /// <param name="p_2">The right operand</param>
        /// <returns>A new CVector resulting from subtracting a second vector from a first vector</returns>
        public static CVector operator -( CVector p_1, CVector p_2 )
        {
            return new CVector( p_1.X - p_2.X, p_1.Y - p_2.Y );
        }

        /// <summary>
        /// Multiply a vector by a scalar
        /// </summary>
        /// <param name="p_vector">The vector operand</param>
        /// <param name="p_scale">The scalar operand</param>
        /// <returns>A new vector containing the operand multiplied by the scalar value</returns>
        public static CVector operator *( CVector p_vector, double p_scale )
        {
            return new CVector( p_vector.X * p_scale, p_vector.Y * p_scale );
        }

        /// <summary>
        /// Divide a vector by a scalar
        /// </summary>
        /// <param name="p_vector">The vector operand</param>
        /// <param name="p_scale">The scalar operand</param>
        /// <returns>A new vector containing the operand divided by the scalar value</returns>
        public static CVector operator /( CVector p_vector, double p_scale )
        {
            return new CVector( p_vector.X / p_scale, p_vector.Y / p_scale );
        }

        /// <summary>
        /// Negate a vector
        /// </summary>
        /// <param name="p_vector">The vector to negate</param>
        /// <returns>A new vector consisting of the negated vector</returns>
        public static CVector operator -( CVector p_vector )
        {
            return new CVector( -p_vector.X, -p_vector.Y );
        }

        /// <summary>
        /// Create a new CVector that contains the unit vector for this vector
        /// </summary>
        /// <returns>A new unit vector</returns>
        public CVector ToUnitVector()
        {
            double len = Length;
            return new CVector( X / len, Y / len );
        }


        /// <summary>
        /// Add a vector to this vector, modifying this vector
        /// </summary>
        /// <param name="p_other">The vector to add</param>
        public void Add( CVector p_other )
        {
            X += p_other.X;
            Y += p_other.Y;
        }

        /// <summary>
        /// Subtract a vector from this vector, modifying this vector
        /// </summary>
        /// <param name="p_other">The vector to subtract</param>
        public void Subtract( CVector p_other )
        {
            X -= p_other.X;
            Y -= p_other.Y;
        }

        /// <summary>
        /// Multiply this vector by a scalar value, modifying this vector
        /// </summary>
        /// <param name="p_scale">The number to multiply this vector by</param>
        public void Multiply( double p_scale )
        {
            X *= p_scale;
            Y *= p_scale;
        }

        /// <summary>
        /// Divide this vector by a scalar value, modifying this vector
        /// </summary>
        /// <param name="p_scale">The number to divide this vector by</param>
        public void Divide( double p_scale )
        {
            X /= p_scale;
            Y /= p_scale;
        }

        /// <summary>
        /// Negate this vector
        /// </summary>
        public void Negate()
        {
            X = -X;
            Y = -Y;
        }

        /// <summary>
        /// Turn this vector into a unit vector
        /// </summary>
        /// <returns></returns>
        public double Normalize()
        {
            double len = Length;
            X /= len;
            Y /= len;
            return len;
        }

        /// <summary>
        /// Calculate the dot-product of this vector and another vector
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>The dot-product, a scalar value</returns>
        public double Dot( CVector p_other )
        {
            return X * p_other.X + Y * p_other.Y;
        }

        /// <summary>
        /// Calculate the dot-product of this vector and another vector- Normalize both vectors first
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>The dot-product, a scalar value</returns>
        private double NormalizedDot( CVector p_other )
        {
            double l1 = Length;
            double x1 = X / l1;
            double y1 = Y / l1;

            double l2 = p_other.Length;
            double x2 = p_other.X / l2;
            double y2 = p_other.Y / l2;

            return x1 * x2 + y1 * y2;
        }

        /// <summary>
        /// Determine if this and another vector are parallel
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are parallel</returns>
        public bool AreParallel( CVector p_other )
        {
            double dot = NormalizedDot( p_other );
            return dot.IsClose( 1 ) || dot.IsClose( -1 );
        }

        /// <summary>
        /// Determine if this and another vector are parallel but pointing in opposite directions
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are parallel but in opposite directions</returns>
        public bool AreParallelOppositeDir( CVector p_other )
        {
            double dot = NormalizedDot( p_other );
            return dot.IsClose( -1 );
        }

        /// <summary>
        /// Determine if this and another vector are parallel and pointing in the same direction
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are parallel and in the same direction</returns>
        public bool AreParallelSameDir( CVector p_other )
        {
            double dot = NormalizedDot( p_other );
            return dot.IsClose( 1 );
        }

        /// <summary>
        /// Determine if this and another vector are orthogonal- perpendicular
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are orthogonal</returns>
        public bool AreOrthogonal( CVector p_other )
        {
            return NormalizedDot( p_other ).IsClose( 0 );
        }

        /// <summary>
        /// Determine if this and another vector form obtuse angles with each other
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are obtuse</returns>
        public bool AreObtuse( CVector p_other )
        {
            return NormalizedDot( p_other ) < 0;
        }

        /// <summary>
        /// Determine if this and another vector form acute angles with each other
        /// </summary>
        /// <param name="p_other">The other vector</param>
        /// <returns>TRUE if the vectors are acute</returns>
        public bool AreAcute( CVector p_other )
        {
            return NormalizedDot( p_other ) > 0;
        }




        /****************************************************************************************
         * The coordinate system for these vectors uses these quadrants:
         * 
         * 
         *                     -PI/2
         *                     
         *                       -
         * 
         *            Q3         |          Q4
         *                       |     
         *             (-1,-1)   |   (1,-1)
         *                       |     
         *                       |     
         *  PI (-PI)  -----------+------------ +   0rad
         *                       |     
         *                       |     
         *              (-1,1)   |   (1,1)   
         *                       |     
         *            Q2         |          Q1        
         * 
         *                       +
         * 
         *                      PI/2
         * 
         * 
         ***************************************************************************************/

        /// <summary>
        /// Create a unit vector from an angle specified in radians
        /// </summary>
        /// <param name="p_radians">The angle to create the unit vector from</param>
        /// <returns>A new CVector (unit) created from the angle specified</returns>
        public static CVector VectorFromRadians( double p_radians )
        {
            return new CVector( Math.Cos( p_radians ), Math.Sin( p_radians ) );
        }

        /// <summary>
        /// Make this CVector a unit vector from an angle specified in radians
        /// </summary>
        /// <param name="p_radians">The angle to create the unit vector from</param>
        public void FromRadians( double p_radians )
        {
            X = Math.Cos( p_radians );
            Y = Math.Sin( p_radians );
        }

        /// <summary>
        /// Turn this vector (assumed to be based at (0,0)) into an angle measure.
        /// </summary>
        /// <returns>The radians (-PI to PI) for this vector</returns>
        public double ToRadians()
        {
            return Math.Atan2( Y, X );
        }


        /// <summary>
        /// Determine if this (point) vector travelling at a specific speed can intersect a second (point) vector travelling at a given linear velocity
        /// </summary>
        /// <param name="p_mySpeed">The speed at which this point can travel</param>
        /// <param name="p_otherPosition">The position of the target point</param>
        /// <param name="p_otherVelocity">The velocity of the target point</param>
        /// <param name="p_interceptPosition">If interception is possible, the point of interception</param>
        /// <param name="p_interceptTime">If interception is possible, the time of interception</param>
        /// <returns>The velocity vector that this point should use in order to intercept, or NULL if interception is not possible</returns>
        public CVector Intercept( double p_mySpeed, CVector p_otherPosition, CVector p_otherVelocity, out CVector p_interceptPosition, out double p_interceptTime )
        {
            // First check- Are we already on top of the target? If so, its valid and we're done
            if (AreSame( p_otherPosition ))
            {
                p_interceptPosition = new CVector( this );
                p_interceptTime = 0;
                return new CVector();
            }

            // Set "out" parameters as if a failure occurred.
            p_interceptPosition = null;
            p_interceptTime = double.NaN;

            // Check- Am I moving?
            if (p_mySpeed <= 0)
                return null;

            double otherSpeed = p_otherVelocity.Length;
            CVector vectorToOther = this - p_otherPosition;
            double distanceToOther = vectorToOther.Length;

            // Check- Is the other thing not moving? If it isn't, the calcs don't work because we can't
            //  use the Law of Cosines
            if (otherSpeed.IsClose( 0 ))
            {
                p_interceptPosition = new CVector( p_otherPosition );
                p_interceptTime = distanceToOther / p_mySpeed;
            }
            else // Everything looks OK for the Law of Cosines approach
            {
                double cosTheta = vectorToOther.Dot( p_otherVelocity ) / (distanceToOther * otherSpeed);

                double a = p_mySpeed * p_mySpeed - otherSpeed * otherSpeed;
                double b = 2 * distanceToOther * otherSpeed * cosTheta;
                double c = -distanceToOther * distanceToOther;

                double t1, t2;
                if (!CMath.QuadraticSolver( a, b, c, out t1, out t2 ))
                    return null;

                if (t1 < 0 && t2 < 0)
                    return null;
                else if (t1 > 0 && t2 > 0)
                    p_interceptTime = Math.Min( t1, t2 );
                else
                    p_interceptTime = Math.Max( t1, t2 );

                p_interceptPosition = new CVector( p_otherVelocity );
                p_interceptPosition.Multiply( p_interceptTime );
                p_interceptPosition.Add( p_otherPosition );
            }

            // Calculate the resulting velocity based on the time and intercept position
            CVector velocity = p_interceptPosition - this;
            velocity.Normalize();
            velocity.Multiply( p_mySpeed );

            return velocity;
        }



        /// <summary>
        /// Turn this vector into a string
        /// </summary>
        /// <returns>Turn this vector into a string</returns>
        public override string ToString()
        {
            return string.Format( "({0:N3},{1:N3})", X, Y );
        }
    }
}
